// mac에서 작업중
console.log("inject.js");

// 화면에 뜨면 삭제 하는 것들.
let delArr = [
    ".fc-ab-root", // 광고 차단 허용, 스크롤 강제막기 삭제
    ".fc-whitelist-root", // 광고차단 머시기
    ".wing_tmp", // 다음 메인 쇼핑 광고.
    "#coupang-banner", // 쿠팡 상단 광고
    ".gnb_bnr_wrap", // SSG.COm 상단 광고
    ".box__component-bigs-filter", // G마켓 플로팅 배너
    "#naver_ad_MenuUnder", // 네이버 스마트 스토어 광고
    "#Banner1", // 잡코리아 상단 광고
    "#newsstand + a", // 네이버 메인 모듈 광고 Layout-module__banner_area ()
];

// 삭제하면 오류가 나서 숨겨만 놔야 하는 것들.
let hiddenArr = [
    ".AdBanner_display_ad_area__s3FEt",
    "#gladbanner.banner_wrap",
    "#view_ad02 + span"
];


function hideAnimation(target, aniBoolean){

    let targetItem = target;
    let flag = aniBoolean;
    targetItem.style.height = targetItem.clientHeight + "px";
    targetItem.classList.add("hideDDAction");
    fnAnimationEnd(targetItem, flag);
}

function fnAnimationEnd(endItem, aniState){
    let aniFlag = aniState;
    if(aniFlag){
        endItem.addEventListener("animationend", function(){
            endItem.classList.add("display-none-important")
        })
    } else {
        endItem.classList.add("display-none-important")
    }

    // endItem.addEventListener("animationend", function(){
    //     console.log("end end end end");
    //     endItem.classList.add("display-none-important")
    // })
}

function hiddenAction(){
    document.body.style.overflow = "";
    const delList = document.querySelectorAll(delArr);
    if(delList.length > 0) {
        delList.forEach(function(item){
            if(item) {
                console.log(item);
                item.remove();
                console.log("삭제됨.")
            }
        })
    }

    const hiddenList = document.querySelectorAll(hiddenArr);
    if(hiddenList.length > 0) {
        hiddenList.forEach(function(item){
            item.style.margin = "0";
            item.style.padding = "0";
            item.style.height = "0";
            item.style.overflow = "hidden";
            item.style.opacity = "0";
            item.style.minHeight = "0";
        })
        alert("hiddenArr")
    }
    
    sizeResizeNaver(); // 네에버 스마트 스토어 탭 메뉴 높이값 줄이기.
}

function fnObserver(){
    const elementToObserve = document.querySelector('body');
    const observer = new MutationObserver(function(mutations) {
        console.log("est")
        mutations.forEach(function(mutation) {
            if (mutation.type == 'childList'){
                hiddenAction();
            }
        });
    });

    const config = {
        attributes:false, 
        childList:true, 
        characterData:false, 
        subtree:true
    };

    observer.observe(elementToObserve, config);
    
    setTimeout(() => {
        console.log("observer.disconnect();")
        observer.disconnect(); 
    }, 5000);
    // observer.disconnect();
}

// fnObserver();

/* 네이버 스마트 스토어 상단메뉴 높이값 줄이기 */
function sizeResizeNaver(){

    let aaa = document.querySelectorAll(".content-header-tab-group .item .tab");
    let bbb = document.querySelectorAll("a.LocalNavigationBar_link__RuoyC");
    let ccc = [...aaa,...bbb];

    if(ccc.length > 0) {
        ccc.forEach(function(item){
            item.style.paddingTop = "17px";
            item.style.paddingBottom = "16px";
            item.style.transition = "0.2s all ease";
            console.log("=============")
        });
    }
}

window.addEventListener("DOMContentLoaded", function(){
    setTimeout(() => {
        console.log("DOMContentLoaded");
        let fcAbRoot = document.querySelector(".fc-ab-root");
        if(fcAbRoot) {
            fcAbRoot.style.display = "none";
            fcAbRoot.remove();
            document.body.style.overflow = "";
        }
    }, 1000);
})


window.addEventListener("load", function(){

    setTimeout(() => {
        let fcAbRoot = document.querySelector(".fc-ab-root");
        if(fcAbRoot) {
            fcAbRoot.style.display = "none";
            fcAbRoot.remove();
            document.body.style.overflow = "";
        }
        console.log("setTimeout fc-ab-root 광고 제거");
    }, 10)


    const url = window.location.href;

    /* 다음 뉴스 */
    // if(url.includes("v.daum.net")){
    //     console.log("v.daum.net가 포함되어있다.")
    // } else {
    //     console.log("v.daum.net가 포함되어있지 않다.")
    // }
    /* indexOf ->   로 변환 */

    
    /* 다음 메인 */
    if (url.includes("https://www.daum.net/")){
        let daumMain = document.querySelectorAll(".inner_main .board_g.board_banner");
        if(daumMain) {
            daumMain.forEach(function(item){
                conAreaDel(item);
            })
        }

        /* 메인 쇼핑 */
        let board_shopping = this.document.querySelector(".board_g.board_shopping");
        if(board_shopping) {
            board_shopping.style.display = "none";
        }
        /* // 메인 쇼핑 */

        let daumMainAsideBnr = document.querySelectorAll(".box_g.box_adgoogle");
        if(daumMainAsideBnr) {
            daumMainAsideBnr.forEach(function(item){
                conAreaDel(item);
            })
        }

        // aside 쇼핑 삭제
        let kakao_ad_area = this.document.querySelector(".kakao_ad_area");
        if(kakao_ad_area) {
            kakao_ad_area.closest(".box_g").style.display = "none";
        }

        /* 메인 추천 게임 */
        let box_game = this.document.querySelector(".box_g.box_game")
        if(box_game) {
            box_game.style.display = "none";
        }
        /* // 메인 추천 게임 */

        /* 메인 핫딜 */
        // shoppinghow-1739518615497
        let hotdeal = this.document.querySelectorAll(".box_g > iframe");
        if(hotdeal) {
            hotdeal.forEach(function(item){
                let attrrrr = item.getAttribute("id");;
                if(attrrrr.includes("shoppinghow")){
                    item.closest(".box_g").style.display = "none";
                }
            })
            // hotdeal.closest(".box_g").style.display = "none";
        }
        /* // 메인 핫딜 */

        /* 메인 aside 랭킹 */
        let box_ranking = this.document.querySelector(".box_g.box_ranking")
        if(box_ranking) {
            box_ranking.style.display = "none";
        }
        /* // 메인 aside 랭킹 */
    }
    /* // 다음 메인 */


    /* 다음 뉴스 */
    if (url.includes("v.daum.net")){
        let daumAside = document.querySelector("body aside.main-etc");
        if(daumAside) {
            daumAside.classList.add("display-none-important")
            conAreaHidden(daumAside);
        }
        let mainContent = document.querySelector("div.main-content");
        if(mainContent) {
            conAreaExtend(mainContent);
            mainContent.classList.add("conExtend");
        }
        let ttalkView = document.querySelector("div.ttalk_view");
        if(ttalkView) {
            conAreaHidden(ttalkView);
        }

        let adBody2 = document.querySelector("div.ad_body2")
        if(adBody2) {
            conAreaHidden(adBody2);
        }
    }




    // 다음 검색 결과 화면
    if(url.includes("https://search.daum.net/")){

        /* 검색결과 화면의 파워링크, 스페셜링크, 프리미엄링크, 애드센스, 스폰서 박스(aside) 삭제 */
        let ad_sch = this.document.querySelectorAll(".ad_sch, .content_sponso, .content_ad, #psbColl");
        if(ad_sch.length > 0){
            ad_sch.forEach(function(item){
                let itemTest = item.parentElement;
                hideAnimation(itemTest, true);
            })
        }
    }
    // 다음 검색 결과 화면 (https://search.daum.net/...)






    // 네이버 메인
    if (url.includes("www.naver.com")){
        console.log(url)
        setTimeout(() => {
            let searchRightRirst = document.querySelector("#search-right-first");
            if(searchRightRirst) {
                searchRightRirst.style.display = "none";
            }

            let searchRightSecond = document.querySelector("#search-right-second");
            if(searchRightSecond) {
                searchRightSecond.style.display = "none";
            }

            
            // 네이버 메이 센터 광고
            let ad_timeboard = document.querySelector("#ad_timeboard");
            if(ad_timeboard) {
                conAreaDel(ad_timeboard);
                let ddss = document.querySelectorAll(".Layout-module__banner_area___CUXNe");
                ddss.forEach(function(item){
                    item.style.opacity = 0;
                    item.style.width = 0;
                    item.style.height = 0;
                    // item.style.display = "none";
                })
                let diejfie = document.querySelector(".Layout-module__content_area___b_3TU + a");
                if(diejfie) {
                    diejfie.style.opacity = 0;
                    diejfie.style.width = 0;
                    diejfie.style.height = 0;
                    // diejfie.style.display = "none";
                }
                // this.document.querySelector(".Layout-module__banner_area___CUXNe").style.display = "none";
                // "#newsstand + a" // 네이버 메인 모듈 광고 Layout-module__banner_area ()
                // 로딩 후 추가 삽입으로 인해 불가.
            }

            let newsstand = document.querySelector("#newsstand");
            if(newsstand){
                newsstand.style.marginTop = 0 + 'px';
            }

            let iframe_rightShopping = this.document.querySelectorAll("iframe");
            if(iframe_rightShopping.length > 0){
                console.log("iframe_rightShoppingiframe_rightShopping")
                iframe_rightShopping.forEach(function(item) {
                    let iframeTitle = item.getAttribute("title");
                    if(iframeTitle && typeof iframeTitle === "string" && iframeTitle.includes("right-shopping")){
                        console.log("asdfasfas")
                    }
                });
            }
            
        }, 0);
    }
    // 네이버 검색 결과 화면 파워링크 영역 삭제 
    if(url.includes("https://search.naver.com/search.naver")){
        let ad_section = this.document.querySelector(".ad_section");
        if(ad_section){
            hideAnimation(ad_section, true)
        }
    }
    // 네이버 검색 결과 화면 파워링크 영역 삭제 
    
    /* 네이버 뉴스 */
    if (url.includes("news.naver.com")){
        let outsideArea = document.querySelector(".outside_area");
        if(outsideArea) {
            conAreaHidden(outsideArea);
        }

        let mainAside = document.querySelector("aside.main_aside");
        if(mainAside) {
            conAreaHidden(mainAside);
        }

        let newsctWrapper = document.querySelector(".newsct_wrapper");
        if(newsctWrapper) {
            newsctWrapper.style.margin = "0 auto";
            newsctWrapper.style.padding = "30px 0";
            newsctWrapper.style.zIndex = 1;
        }

        // 언론사 구독 후 기사보기
        let subscribeCtaLayer = document.querySelectorAll(".subscribe_cta_layer")
        if(subscribeCtaLayer.length > 0){
            subscribeCtaLayer.forEach(function(item){
                conAreaDel(item);
            })
        }

        let pressAside = document.querySelector("section.press_aside");
        if(pressAside) {
            conAreaDel(pressAside);
        }
        
        let newsLine = document.querySelector(".ct_scroll_wrapper");
        if(newsLine) {
            naverAfterLine();
            // newsLine.style.opacity = "0";
        }

        let adArea = this.document.querySelector(".ad_area");
        if(adArea) {
            conAreaDel(adArea);
        }
    }

    /* 이데일리 뉴스 */
    if(url.includes("edaily.co.kr")){

        let add01 = document.querySelector(".election_2022.government.sp_sub + span");
        if(add01) {
            conAreaStyle(add01);
        }
        let aside = document.querySelector("#aside_right");
        if(aside) {
            conAreaStyle(aside);
        }

        let floatingBnr = document.querySelector("section.center1080.position_r > span");
        if(floatingBnr) {
            conAreaStyle(floatingBnr);
        }

        let contentBnr = document.querySelector("br + span");
        if(contentBnr) {
            conAreaStyle(contentBnr);
        }

        let secondTextAD = document.querySelector(".second_textAD");
        if(secondTextAD) {
            conAreaDel(secondTextAD);
        }

        let newsDomino = document.querySelector(".news_domino");
        if(newsDomino) {
            conAreaDel(newsDomino);
        }

        let articleNewsetc = document.querySelector(".article_newsetc");
        if(articleNewsetc) {
            conAreaDel(articleNewsetc);
        }

        let newsAuthor = document.querySelector(".stiky_newscontainer");
        if(newsAuthor) {
            conAreaDel(newsAuthor);
        }
    }

    // 한겨례 뉴스
    if(url.includes("hani.co.kr")){
        let aRight = this.document.querySelector(".a-right");
        let aLeft = this.document.querySelector(".a-left");
        if(aRight) {
            conAreaDel(aRight);
            conAreaExtend(aLeft)
            aLeft.style.margin = "0 auto";
            aLeft.style.padding = "0";
        }

        let adBox01 = this.document.querySelector("#ad_box01")
        let adBox01div = this.document.querySelector("#ad_box01 + div")
        if(adBox01) {
            conAreaStyle(adBox01div);
            conAreaDel(adBox01);
            aLeft.style.margin = "0 auto";
        }

        let articleText = this.document.querySelectorAll(".article-text ~ div")
        articleText.forEach(function(item){
            conAreaStyle(item);
        })
    }


    // etoday.co.kr/news
    if(url.includes("etoday.co.kr/news")){
        let rContentModule = this.document.querySelector(".r_content_module");
        let lContentModule = this.document.querySelector(".l_content_module");
        if(rContentModule) {
            conAreaStyle(rContentModule);
            conAreaExtend(lContentModule)
        }

        let quickLeft = this.document.querySelector("#quick_left");
        if(quickLeft) {
            conAreaStyle(quickLeft);
        }

        let quickRight = this.document.querySelector("article.containerWrap > span");
        if(quickRight) {
            conAreaStyle(quickRight);
        }

        let viewInnerAd = this.document.querySelector(".articleView > p + span");
        if(viewInnerAd) {
            conAreaStyle(viewInnerAd);
        }

        // 주요 뉴스
        let majListWrap = this.document.querySelector(".maj_list_wrap"); 
        let majListWrapSpan = this.document.querySelector(".maj_list_wrap + span"); 
        if(majListWrap) {
            conAreaStyle(majListWrap);
            conAreaStyle(majListWrapSpan);
        }
    }


    
    

    

    // https://manatoki340.net/
    if(url.includes("manatoki")){
        
        let mainBannerView = this.document.querySelector("#main-banner-view");
        if(mainBannerView) {
            hideAnimation(mainBannerView, true);
            // conAreaDel(mainBannerView, true);
        }
        let idmbv = this.document.querySelector("#id_mbv");
        if(idmbv) {
            conAreaDel(idmbv, true);
        }
        let boardtailbanner = this.document.querySelector(".board-tail-banner");
        if(boardtailbanner) {
            conAreaDel(boardtailbanner, true);
        }

        let hd_pop = this.document.querySelector("#hd_pop"); // 메인페이지 팝업
        if(hd_pop){
            let hd_pop_btns = hd_pop.querySelectorAll("button.hd_pops_close");
            if(hd_pop_btns && hd_pop_btns.length > 0) {
                hd_pop_btns.forEach(function(item){
                    item.click();
                })
            }
        }
        
        if(url.includes("comic")){ // 뷰페이지에서만 가림
            let atWrap = this.document.querySelector("#at-wrap");
            if(atWrap) {
                atWrap.style.paddingRight = "0"
            }
            
            let atRight = this.document.querySelector("#at-right");
            if(atRight) {
                conAreaDel(atRight, true);
            }
        }
    } // https://manatoki340.net/


    // https://namu.wiki/
    if(url.includes("https://namu.wiki/w/")){
        console.log("나무위키");
        /* 나무위키 구글 광고 제거 */
        // setTimeout(() => {
        //     let googleAdsIframe = document.querySelectorAll("iframe");
        //     if(googleAdsIframe.length > 0) {
        //         googleAdsIframe.forEach(function(item,index){
        //             let iframeDiv = item.closest("div");
        //             if(iframeDiv) {
        //                 item.classList.add("아이프레임");
        //                 item.style.display = "none";
        //                 iframeDiv.style.display = "none";
        //                 iframeDiv.classList.add(displayNoneImportant);
        //             }
        //         })
        //     }
        // }, 5000)
        /* // 나무위키 구글 광고 제거 */



        setTimeout(() => {
            let googleAdsIframe = document.querySelectorAll("iframe");
            if(googleAdsIframe.length > 0) {
                googleAdsIframe.forEach(function(item,index){
    
                    let iframeDiv = item.closest("div");
                    let iframeDivId;
                    if(iframeDiv) {
                        iframeDivId = iframeDiv.getAttribute("id");
                    }
                    if(iframeDivId && typeof iframeDivId === "string" && iframeDivId.includes("google_ads_iframe")) {
                        
                        let secondDivTest = iframeDiv.parentElement;
                        let thirdDivTest = secondDivTest.parentElement;
                        console.log(secondDivTest);
                        console.log(thirdDivTest);
                        hideAnimation(thirdDivTest, true);
                        // thirdDivTest.style.display = "none";
                    }
                })
            }
        }, 1000)

        setTimeout(() => {
            let divTemp = document.querySelectorAll("div");
            if(divTemp.length > 0){
                divTemp.forEach(function(item,index){
                    let dddiv = item;
                    let xxxdiv;
                    if(dddiv) {
                        xxxdiv = dddiv.getAttribute("id");
                    }
                    if(xxxdiv  &&  typeof xxxdiv === "string" && xxxdiv.includes("google_ads_iframe")){
                        let firstDiv = item.parentElement;
                        let secondDivTest = firstDiv.parentElement;
                        hideAnimation(secondDivTest, true);
                        // secondDivTest.style.display = "none";
                    }
                })
            }
            
        }, 1000)

    } // https://namu.wiki/





    // utweb torrent
    if(url.includes("utweb")){

        setTimeout(() => {
            let cardContainer = this.document.querySelectorAll(".card-container");
            if(cardContainer) {
                cardContainer.forEach(function(item){
                    //item.style.display = "none";
                })

                // 메인 메뉴 아이콘 삭제
                var divElement = document.createElement('div');
                divElement.innerHTML = `
                <style>
                .card-container {display:none !important;}
                .media-library-top-container.show-ad {top:0 !important;}
                </style>
                `
                document.body.appendChild(divElement);

                // conAreaDel(cardContainer, true);
            }

            // cardContainer.forEach(function(item){
            //     item.style.opacity = 0;
            //     item.style.width = 0;
            //     item.style.height = 0;
            //     // item.style.display = "none";
            //     console.log("dddda");
            // })

            let mediaLibraryTopContainer = this.document.querySelector(".media-library-top-container");
            if(mediaLibraryTopContainer) {
                mediaLibraryTopContainer.classList.remove("show-ad");
            }
        }, 100);
        
    } // utweb torrent
    

    /* ====== 기업형 광고 제거 ====== */
    
    /* 랜덤 사이트 애드오피스(https://adop.cc/) 광고 제거 */
    let insAdsbyadops = this.document.querySelectorAll("ins");
    if(insAdsbyadops.length > 0) {
        setTimeout(() => {
            insAdsbyadops.forEach(function(item,index){
                let insClass = item.getAttribute("class");
                if (insClass && typeof insClass === "string" && insClass.includes("adsbyadop")) {
                    item.style.display = "none";
                    /* 특정 페이지에서 컨텐츠가 모두 사라지는 경우가 생김. */
                    // const parentDiv = item.closest("div");
                    // if(parentDiv) {
                    //     parentDiv.style.display = "none";
                    // }
                }
            })
        }, 0)
    }
    /* // 랜덤 사이트 애드오피스(https://adop.cc/) 광고 제거 */

    /* 랜덤 사이트 구글 광고 제거 */
    let adsbygoogles = this.document.querySelectorAll(".adsbygoogle");
    if(adsbygoogles.length > 0) {
        setTimeout(() => {
            adsbygoogles.forEach(function(item,index){
                item.style.display = "none";
                /* 특정 페이지에서 컨텐츠가 모두 사라지는 경우가 생김. */
                // const parentDiv = item.closest("div");
                // if(parentDiv) {
                //     parentDiv.style.display = "none";
                // }
            })
        }, 0)
    }
    /* // 랜덤 사이트 구글 광고 제거 */

    /* iframe 에 담겨있는 구글 광고 제거 (상위 div 삭제) */
    let adsbygooglesIframe = this.document.querySelectorAll("iframe");
    if(adsbygooglesIframe.length > 0) {
        setTimeout(() => {
            adsbygooglesIframe.forEach(function(item,index){
                let iframeId = item.getAttribute("id");
                if (iframeId && typeof iframeId === "string" && iframeId.includes("google")) {
                    const parentDiv = item.closest("div");
                    if(parentDiv) {
                        parentDiv.classList.add("test123")
                        parentDiv.style.display = "none";
                        console.log("불특정다수의 iframe 상위 div 삭제 / 가끔 보여야 하는게 지워지기도 함.");
                    }
                }
            })
        }, 0)
    }
    /* // iframe 에 담겨있는 구글 광고 제거 (상위 div 삭제) */

    /* // ====== 기업형 광고 제거 ====== */

})

/* 불필요한 내용 숨기기 */
function conAreaHidden(item){
    item.style.display = "none";
}

/* 컨텐츠 영역 확장 */
function conAreaExtend (item){
    // item.style.width = "auto";
    // item.style.maxWidth = "100%";
    item.style.float = "none";
    item.style.margin = "0 auto";
    item.style.padding = "0";
}

function conAreaDel(item, state){
    if(true == state){
        // InsertTrace(item)
    }
    item.remove();
}

function conAreaStyle(item){
    item.style.position = "absolute";
    item.style.top = "0px";
    item.style.left = "0px";
    item.style.width = "0px";
    item.style.minWidth = "0px";
    item.style.height = "0px";
    item.style.minHeight = "0px";
    item.style.margin = "0px";
    item.style.padding = "0px";
    item.style.opacity = "0";
    item.style.overflow = "hidden";
}

function InsertTrace(target){
    const testDiv = document.createElement("div");
    testDiv.classList.add("traceDiv")
    let tempconInner = `
    <div><span>광고영역 제거됨 / 광고를 제거해서 화면을 넓게 써보자.</span></div>`;
    testDiv.innerHTML = tempconInner;
    target.parentNode.insertBefore(testDiv, target.nextSibling);
}


function naverAfterLine(){
    console.log("naverAfterLine")
    let naverNewsDiv = document.createElement("div");
    naverNewsDiv.classList.add("after");
    
    let newsTest = document.querySelector(".end_container");
    let tempStyle = `
        <style>
        .ct_scroll_wrapper::after {display:none !important;}

        @media (min-width: 1080px) {
            .as_section_home .column0 + .newsct_wrapper {
                // width: 645px;
                // padding-left: 30px;
                // padding-right: 31px;
                // flex: 1;
                // padding: 30px 30px !important;
            }
        }
        </style>
    `;
    naverNewsDiv.innerHTML = tempStyle;
    newsTest.parentNode.insertBefore(naverNewsDiv, newsTest.nextSibling);
}


// function test1234() {
//     console.log('test1234 function executed in inject.js');
// }
// window.test1234 = test1234;
// window.InsertTrace = InsertTrace;




function addImportant(target){
    const div = document.createElement("div");
    div.classList.add("custom_css");
    div.classList.add("inject");
    let tempconInner = `
        <style>
        .conExtend {float:unset; margin:0 auto; padding:0;}
        .traceDiv {margin:1px; padding:10px; background-color:#f9f9f9; color:#666; font-size:12px; line-height:1em; text-align:center;}
        .display-none-important {display:none !important;}
        .hideDDAction {animation: hideAnimation 0.3s 1 forwards ease;}
        @keyframes hideAnimation {
            0% {}
            100% {height:0; margin:0; padding:0; opacity:0; transform:scale(0.5); transform-origin:50% 0; z-index:0; overflow:hidden;}
        }
        </style>
    `;
    div.innerHTML = tempconInner;
    target.parentNode.insertBefore(div, target.nextSibling);
}
window.addImportant = addImportant;