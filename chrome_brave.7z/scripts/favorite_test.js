window.addEventListener("load", function(){

    console.log("favorite.js");

    // danawa
    if(url.includes("danawa.com")){

        // 상단 서브 메뉴 (비교사이트)
        let cwGnb = this.document.querySelector(".cw-gnb");
        if(cwGnb) {
            conAreaDel(cwGnb, false);
        }

        // 메인 메뉴 아이콘 삭제
        var divElement = document.createElement('div');
        divElement.classList.add("danawa");
        divElement.innerHTML = `
        <style>
        .category__list__btn {box-sizing:border-box; justify-content:space-between; width:100%; height:auto; padding-right:8px; font-size:14px; color:#fff; font-weight:600; text-indent:0; text-decoration:none; text-shadow:0 1px 2px rgba(0,0,0,0.16);}
        .category__list__row.active .category__list__btn {color:#000; text-decoration:none;}
        .aside-vs>.box__layer>.box__inner {width:270px;}
        .aside-vs>.box__layer .list__slot .box__product .box__thumbnail {width:80px;}
        // .category__list__btn:before {content:unset;}
        </style>
        `
        document.body.appendChild(divElement);
    }

    if(url.includes("prod.danawa.com")){
        // 메인 페이지
        // 메인 중앙 배너 영역 삭제
        let mainMiddlebnr = this.document.querySelector("#main-middlebnr");
        if(mainMiddlebnr) {
            conAreaDel(mainMiddlebnr, true);
            // this.document.querySelector(".main-info").style.marginTop = "14px";
        }

        // 다나와 상단 광고,
        let ttopBanner = this.document.querySelector(".ttop_banner");
        if(ttopBanner) {
            conAreaDel(ttopBanner, false);
        }

        // 상품 목록 상단 광고 영역 애드 리더
        let mainAdReader = this.document.querySelector("#mainAdReader");
        if(mainAdReader) {
            conAreaDel(mainAdReader, true);
        }

        // 상품 목록 중간 광고 영역 : 애드 포인트
        let adPointArea = this.document.querySelector("#adPointArea");
        if(adPointArea) {
            conAreaDel(adPointArea, true);
        }

        // 왼쪽 날개배너 프리미엄 배너
        let premiumBanner = this.document.querySelector("#premiumBanner");
        if(premiumBanner) {
            conAreaDel(premiumBanner, false);
        }

        // 상품 목록 페이지 상단 광고 영역 : 이런 상품 어때요
        let naverPowerShoppingArea = this.document.querySelector("#naverPowerShoppingArea");
        if(naverPowerShoppingArea) {
            conAreaDel(naverPowerShoppingArea, true);
        }

        // 상품 목록 페이지 하단 광고 영역 : 파워클릭
        let ebayPowerClickBottomArea = this.document.querySelector("#ebayPowerClickBottomArea");
        if(ebayPowerClickBottomArea) {
            conAreaDel(ebayPowerClickBottomArea, true);
        }

        // 상품목록 우측 영역        
        let asideMedia = this.document.querySelector(".aside_media");
        if(asideMedia) {
            let danawaContainer = this.document.querySelector("#danawa_container");
            if(danawaContainer) {
                danawaContainer.style.paddingRight = "0";
            }
            conAreaDel(asideMedia, false);
        }


        // 1. 감시할 대상 요소를 찾습니다.
        const targetElement = document.querySelector('.aside-vs');

        if (targetElement) {
            // 2. 콜백 함수를 정의합니다.
            // MutationObserver는 변경 사항 목록(mutationsList)과 Observer 자신(observer)을 인자로 받습니다.
            const callback = function(mutationsList, observer) {
                for (const mutation of mutationsList) {
                    // 변경 타입이 'attributes' (속성 변경)이고,
                    // 변경된 속성이 'class'일 때만 처리합니다.
                    if (mutation.type === 'attributes' && mutation.attributeName === 'class') {

                        // 현재 요소의 클래스 리스트를 확인합니다.
                        const classList = targetElement.classList;

                        if (classList.contains('on')) {
                            // 'on' 클래스가 추가된 경우
                            console.log("✅ 'aside-vs' 요소에 'on' 클래스가 추가되었습니다.");
                            document.querySelector("#danawa_container").style.paddingRight = "280px"
                        } else {
                            // 'on' 클래스가 삭제된 경우
                            // (이전에는 'on'이 있었는데 현재는 없다는 의미)
                            console.log("❌ 'aside-vs' 요소에서 'on' 클래스가 삭제되었습니다.");
                            document.querySelector("#danawa_container").style.paddingRight = "0"
                        }
                    }
                }
            };

            // 3. Observer 인스턴스를 생성하고 옵션을 설정합니다.
            const observer = new MutationObserver(callback);

            // Observer 설정 옵션
            const config = {
                attributes: true,        // 속성 변경을 감지합니다. (필수: class 속성 변경을 위해)
                attributeFilter: ['class'] // 'class' 속성 변경만 필터링하여 감지 성능을 최적화합니다.
            };

            // 4. 감시를 시작합니다.
            observer.observe(targetElement, config);
            console.log("Observer가 '.aside-vs' 요소의 클래스 변경 감시를 시작했습니다.");

        } else {
            console.error("⚠️ 페이지에서 '.aside-vs' 요소를 찾을 수 없습니다.");
        }
    } // danawa.com

})