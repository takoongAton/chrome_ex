console.log("communication.js");
window.addEventListener("load", function(){

    /* body 다음 태그에 custom css 추가 (inject.js 파일에 있음.) */
    let bodyTag = this.document.querySelector("body");
    addImportantCss(bodyTag);





    /* 연합뉴스 (https://www.yna.co.kr/view) */
    if(url.includes("https://www.yna.co.kr/view")){

        // 페이지 상단 배너 
        let asideTopBnr01 = this.document.querySelector(".aside-top-bnr01");
        if(asideTopBnr01) {
            // conAreaDel(asideTopBnr01, true);
            asideTopBnr01.classList.add(displayNoneImportant);
        }

        // aside 태그로 되어있는 것들 숨김
        let asideBox = this.document.querySelectorAll("aside");
        if(asideBox.length > 0) {
            setTimeout(() => {
                asideBox.forEach(function(item,index){
                    item.classList.add(displayNoneImportant);
                })
            }, 0)
        }
    }
    /* // 연합뉴스 (https://www.yna.co.kr/view ) */





    /* 여성신문 (https://www.womennews.co.kr/news) */
    if(url.includes("https://www.womennews.co.kr/news")){
        // 외부 광고영역 제거
        let adTemplate = this.document.querySelectorAll(".ad-template");
        if(adTemplate.length > 0) {
            setTimeout(() => {
                adTemplate.forEach(function(item,index){
                    item.classList.add(displayNoneImportant);
                })
            }, 0)
        }

        // 여성신문 자체 광고영역 제거
        let bannerBox = this.document.querySelectorAll(".banner_box");
        if(bannerBox.length > 0) {
            setTimeout(() => {
                bannerBox.forEach(function(item,index){
                    item.classList.add(displayNoneImportant);
                })
            }, 0)
        }

        // 후원하기 삭제
        let supportBox = this.document.querySelector("#support_box");
        if(supportBox) {
            supportBox.classList.add(displayNoneImportant);
        }

        // 우측 플로팅 배너 삭제
        let wpAdbnRoot = this.document.querySelector("#wp_adbn_root");
        if(wpAdbnRoot) {
            wpAdbnRoot.classList.add(displayNoneImportant);
        }
    }
    /* // 여성신문 (https://www.womennews.co.kr/news) */




    /* dcinside */

    /* 갤러리 리스트 상단 */
    let issueContentbox = this.document.querySelector(".issue_contentbox");
    if(issueContentbox) {
        issueContentbox.classList.add(displayNoneImportant);
    }

    let taboolaRightRailThumbnails = this.document.querySelector("#taboola-right-rail-thumbnails");
    if(taboolaRightRailThumbnails) {
        taboolaRightRailThumbnails.classList.add(displayNoneImportant);
    }

    let rightbanner1 = this.document.querySelector(".rightbanner1");
    if(rightbanner1) {
        rightbanner1.classList.add(displayNoneImportant);
    }

    let stickyunit = this.document.querySelector(".stickyunit");
    if(stickyunit) {
        stickyunit.classList.add(displayNoneImportant);
    }

    /* 디시트랜드 랭킹 */
    let dctrendanking = this.document.querySelector(".dctrend_ranking");
    if(dctrendanking) {
        dctrendanking.classList.add(displayNoneImportant);
    }



    function addImportantCss(target){
        const div = document.createElement("div");
        div.classList.add("custom_css")
        let tempconInner = `
            <style>
            .gall_list tr.thum .gall_tit {height:auto;}
            .gall_list td {padding:10px;}
            /* 제미나이 크롬 영역 확장 */
            .conversation-container {max-width:1440px !important;}
            .conversation-container > user-query {max-width:1440px !important;}
            .text-base > div:first-of-type {max-width:1440px !important;}
            .w-fit {width:auto;}
            </style>
            `;
        div.innerHTML = tempconInner;
        target.parentNode.insertBefore(div, target.nextSibling);
    }
    window.addImportantCss = addImportantCss;
    
    /* // dcinside */




    
});
// window.addEventListener("load", function(){})