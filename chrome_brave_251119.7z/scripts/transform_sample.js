function conAreaDel(item, state){
    // if(true == state){ insertTrace(item) }
    // if(true == state) insertTrace(item)
    if(state){
        // insertTrace(item);
    }
    item.remove();
}



function hideAnimation(target, aniBoolean){

    let targetItem = target;
    let flag = aniBoolean;
    targetItem.style.height = targetItem.clientHeight + "px";
    targetItem.classList.add("hideDDAction");
    fnAnimationEnd(targetItem, flag);
}

function fnAnimationEnd(endItem, aniState){
    let aniFlag = aniState;
    if(aniFlag){
        endItem.addEventListener("animationend", function(){
            endItem.classList.add("display-none-important")
        })
    } else {
        endItem.classList.add("display-none-important")
    }

    // endItem.addEventListener("animationend", function(){
    //     console.log("end end end end");
    //     endItem.classList.add("display-none-important")
    // })
}



// danawa.com
    if(url.includes("prod.danawa.com")){
        // 메인 페이지
        // 메인 중앙 배너 영역 삭제
        let mainMiddlebnr = this.document.querySelector("#main-middlebnr");
        if(mainMiddlebnr) {
            conAreaDel(mainMiddlebnr, true);
            // this.document.querySelector(".main-info").style.marginTop = "14px";
        }

        // 다나와 상단 광고,
        let ttopBanner = this.document.querySelector(".ttop_banner");
        if(ttopBanner) {
            conAreaDel(ttopBanner, false);
        }

        // 상품 목록 상단 광고 영역 애드 리더
        let mainAdReader = this.document.querySelector("#mainAdReader");
        if(mainAdReader) {
            conAreaDel(mainAdReader, true);
        }

        // 상품 목록 중간 광고 영역 : 애드 포인트
        let adPointArea = this.document.querySelector("#adPointArea");
        if(adPointArea) {
            conAreaDel(adPointArea, true);
        }

        // 왼쪽 날개배너 프리미엄 배너
        let premiumBanner = this.document.querySelector("#premiumBanner");
        if(premiumBanner) {
            conAreaDel(premiumBanner, false);
        }

        // 상품 목록 페이지 상단 광고 영역 : 이런 상품 어때요
        let naverPowerShoppingArea = this.document.querySelector("#naverPowerShoppingArea");
        if(naverPowerShoppingArea) {
            conAreaDel(naverPowerShoppingArea, true);
        }

        // 상품 목록 페이지 하단 광고 영역 : 파워클릭
        let ebayPowerClickBottomArea = this.document.querySelector("#ebayPowerClickBottomArea");
        if(ebayPowerClickBottomArea) {
            conAreaDel(ebayPowerClickBottomArea, true);
        }

        // 상품목록 우측 영역        
        let asideMedia = this.document.querySelector(".aside_media");
        if(asideMedia) {
            let danawaContainer = this.document.querySelector("#danawa_container");
            if(danawaContainer) {
                danawaContainer.style.paddingRight = "0";
            }
            conAreaDel(asideMedia, false);
        }

        let daumMain = document.querySelectorAll(".inner_main .board_g.board_banner");
        if(daumMain) {
            daumMain.forEach(function(item){
                conAreaDel(item);
            })
        }


        if(url.includes("comic")){ // 뷰페이지에서만 가림
            let atWrap = this.document.querySelector("#at-wrap");
            if(atWrap) {
                atWrap.style.paddingRight = "0"
            }
            
            let atRight = this.document.querySelector("#at-right");
            if(atRight) {
                conAreaDel(atRight, true);
            }
        }
    } // danawa.com


