// mac에서 작업중
console.log("inject.js");

const url = window.location.href;

// 화면에 뜨면 삭제 하는 것들.
let delArr = [
    ".fc-ab-root", // 광고 차단 허용, 스크롤 강제막기 삭제
    ".fc-whitelist-root", // 광고차단 머시기
    "#coupang-banner", // 쿠팡 상단 광고
    ".gnb_bnr_wrap", // SSG.COm 상단 광고
    ".box__component-bigs-filter", // G마켓 플로팅 배너
    "#Banner1", // 잡코리아 상단 광고
];

// 삭제하면 오류가 나서 숨겨만 놔야 하는 것들.
let hiddenArr = [
    ".AdBanner_display_ad_area__s3FEt",
    "#gladbanner.banner_wrap",
    "#view_ad02 + span"
];


function hideAnimation(target, aniBoolean){

    let targetItem = target;
    let flag = aniBoolean;
    targetItem.style.height = targetItem.clientHeight + "px";
    targetItem.classList.add("hideDDAction");
    fnAnimationEnd(targetItem, flag);
}

function fnAnimationEnd(endItem, aniState){
    let aniFlag = aniState;
    if(aniFlag){
        endItem.addEventListener("animationend", function(){
            endItem.classList.add("display-none-important")
        })
    } else {
        endItem.classList.add("display-none-important")
    }

    // endItem.addEventListener("animationend", function(){
    //     console.log("end end end end");
    //     endItem.classList.add("display-none-important")
    // })
}

function hiddenAction(){
    document.body.style.overflow = "";
    const delList = document.querySelectorAll(delArr);
    if(delList.length > 0) {
        delList.forEach(function(item){
            if(item) {
                console.log(item);
                item.remove();
                console.log("삭제됨.")
            }
        })
    }

    const hiddenList = document.querySelectorAll(hiddenArr);
    if(hiddenList.length > 0) {
        hiddenList.forEach(function(item){
            item.style.margin = "0";
            item.style.padding = "0";
            item.style.height = "0";
            item.style.overflow = "hidden";
            item.style.opacity = "0";
            item.style.minHeight = "0";
        })
        alert("hiddenArr")
    }
}

function fnObserver(){
    const elementToObserve = document.querySelector('body');
    const observer = new MutationObserver(function(mutations) {
        console.log("est")
        mutations.forEach(function(mutation) {
            if (mutation.type == 'childList'){
                hiddenAction();
            }
        });
    });

    const config = {
        attributes:false, 
        childList:true, 
        characterData:false, 
        subtree:true
    };

    observer.observe(elementToObserve, config);
    
    setTimeout(() => {
        console.log("observer.disconnect();")
        observer.disconnect(); 
    }, 5000);
    // observer.disconnect();
}

// fnObserver();


window.addEventListener("load", function(){
    console.log("load");

    setTimeout(() => {
        let fcAbRoot = document.querySelector(".fc-ab-root");
        if(fcAbRoot) {
            fcAbRoot.style.display = "none";
            fcAbRoot.remove();
            document.body.style.overflow = "";
        }
        if(fcAbRoot) {
            console.log("setTimeout fc-ab-root 광고 제거");
        }
    }, 10)


    

    /* 다음 뉴스 */
    // if(url.includes("v.daum.net")){
    //     console.log("v.daum.net가 포함되어있다.")
    // } else {
    //     console.log("v.daum.net가 포함되어있지 않다.")
    // }
    /* indexOf -> includes 로 변환 */

    
    /* 다음 메인 */
    if (url.includes("https://www.daum.net/")){
        let daumMain = document.querySelectorAll(".inner_main .board_g.board_banner");
        if(daumMain) {
            daumMain.forEach(function(item){
                conAreaDel(item);
            })
        }

        /* 메인 쇼핑 */
        let board_shopping = this.document.querySelector(".board_g.board_shopping");
        if(board_shopping) {
            board_shopping.style.display = "none";
        }
        /* // 메인 쇼핑 */

        let daumMainAsideBnr = document.querySelectorAll(".box_g.box_adgoogle");
        if(daumMainAsideBnr) {
            daumMainAsideBnr.forEach(function(item){
                conAreaDel(item);
            })
        }

        // aside 쇼핑 삭제
        let kakao_ad_area = this.document.querySelector(".kakao_ad_area");
        if(kakao_ad_area) {
            kakao_ad_area.closest(".box_g").style.display = "none";
        }

        /* 메인 추천 게임 */
        let box_game = this.document.querySelector(".box_g.box_game")
        if(box_game) {
            box_game.style.display = "none";
        }
        /* // 메인 추천 게임 */

        /* 메인 핫딜 */
        // shoppinghow-1739518615497
        let hotdeal = this.document.querySelectorAll(".box_g > iframe");
        if(hotdeal) {
            hotdeal.forEach(function(item){
                let attrrrr = item.getAttribute("id");;
                if(attrrrr.includes("shoppinghow")){
                    item.closest(".box_g").style.display = "none";
                }
            })
            // hotdeal.closest(".box_g").style.display = "none";
        }
        /* // 메인 핫딜 */

        /* 메인 aside 랭킹 */
        let box_ranking = this.document.querySelector(".box_g.box_ranking")
        if(box_ranking) {
            box_ranking.style.display = "none";
        }
        /* // 메인 aside 랭킹 */
    }
    /* // 다음 메인 */


    /* 다음 뉴스 */
    if (url.includes("v.daum.net")){
        let daumAside = document.querySelector("body aside.main-etc");
        if(daumAside) {
            daumAside.classList.add("display-none-important")
            conAreaHidden(daumAside);
        }
        let mainContent = document.querySelector("div.main-content");
        if(mainContent) {
            conAreaExtend(mainContent);
            mainContent.classList.add("conExtend");
        }
        let ttalkView = document.querySelector("div.ttalk_view");
        if(ttalkView) {
            conAreaHidden(ttalkView);
        }

        let adBody2 = document.querySelector("div.ad_body2")
        if(adBody2) {
            conAreaHidden(adBody2);
        }
    }




    // 다음 검색 결과 화면
    if(url.includes("https://search.daum.net/")){
        /* 검색결과 화면의 파워링크, 스페셜링크, 프리미엄링크, 애드센스, 스폰서 박스(aside) 삭제 */
        let ad_sch = this.document.querySelectorAll(".ad_sch, .content_sponso, .content_ad, #psbColl");
        if(ad_sch.length > 0){
            ad_sch.forEach(function(item){
                let itemTest = item.parentElement;
                hideAnimation(itemTest, true);
            })
        }
    }
    // 다음 검색 결과 화면 (https://search.daum.net/...)





    
    

    

    


    





    // utweb torrent
    if(url.includes("utweb")){

        setTimeout(() => {
            let cardContainer = this.document.querySelectorAll(".card-container");
            if(cardContainer) {
                cardContainer.forEach(function(item){
                    //item.style.display = "none";
                })

                // 메인 메뉴 아이콘 삭제
                var divElement = document.createElement('div');
                divElement.innerHTML = `
                <style>
                .card-container {display:none !important;}
                .media-library-top-container.show-ad {top:0 !important;}
                </style>
                `
                document.body.appendChild(divElement);

                // conAreaDel(cardContainer, true);
            }

            // cardContainer.forEach(function(item){
            //     item.style.opacity = 0;
            //     item.style.width = 0;
            //     item.style.height = 0;
            //     // item.style.display = "none";
            //     console.log("dddda");
            // })

            let mediaLibraryTopContainer = this.document.querySelector(".media-library-top-container");
            if(mediaLibraryTopContainer) {
                mediaLibraryTopContainer.classList.remove("show-ad");
            }
        }, 100);
        
    } // utweb torrent
    

    /* ====== 기업형 광고 제거 ====== */
    
    /* 랜덤 사이트 애드오피스(https://adop.cc/) 광고 제거 */
    let insAdsbyadops = this.document.querySelectorAll("ins");
    if(insAdsbyadops.length > 0) {
        setTimeout(() => {
            insAdsbyadops.forEach(function(item,index){
                let insClass = item.getAttribute("class");
                if (insClass && typeof insClass === "string" && insClass.includes("adsbyadop")) {
                    item.style.display = "none";
                    /* 특정 페이지에서 컨텐츠가 모두 사라지는 경우가 생김. */
                    // const parentDiv = item.closest("div");
                    // if(parentDiv) {
                    //     parentDiv.style.display = "none";
                    // }
                }
            })
        }, 0)
    }
    /* // 랜덤 사이트 애드오피스(https://adop.cc/) 광고 제거 */

    /* 랜덤 사이트 구글 광고 제거 */
    let adsbygoogles = this.document.querySelectorAll(".adsbygoogle");
    if(adsbygoogles.length > 0) {
        setTimeout(() => {
            adsbygoogles.forEach(function(item,index){
                item.style.display = "none";
                /* 특정 페이지에서 컨텐츠가 모두 사라지는 경우가 생김. */
                // const parentDiv = item.closest("div");
                // if(parentDiv) {
                //     parentDiv.style.display = "none";
                // }
            })
        }, 0)
    }
    /* // 랜덤 사이트 구글 광고 제거 */

    /* iframe 에 담겨있는 구글 광고 제거 (상위 div 삭제) */
    let adsbygooglesIframe = this.document.querySelectorAll("iframe");
    if(adsbygooglesIframe.length > 0) {
        setTimeout(() => {
            adsbygooglesIframe.forEach(function(item,index){
                let iframeId = item.getAttribute("id");
                if (iframeId && typeof iframeId === "string" && iframeId.includes("google")) {
                    const parentDiv = item.closest("div");
                    const parentIns = item.closest("ins");
                    if(parentIns) {
                        parentIns.classList.add("test123");
                        console.log(parentIns);
                        parentIns.style.display = "none";
                        console.log("불특정다수의 iframe 상위 ins 삭제 / 가끔 보여야 하는게 지워지기도 함.");
                        return false;
                    }
                    if(parentDiv) {
                        parentDiv.classList.add("test123");
                        console.log(parentDiv);
                        parentDiv.style.display = "none";
                        console.log("불특정다수의 iframe 상위 div 삭제 / 가끔 보여야 하는게 지워지기도 함.");
                    }
                }
            })
        }, 0)
    }
    /* // iframe 에 담겨있는 구글 광고 제거 (상위 div 삭제) */

    /* // ====== 기업형 광고 제거 ====== */

})

/* 불필요한 내용 숨기기 */
function conAreaHidden(item){
    item.style.display = "none";
}

/* 컨텐츠 영역 확장 */
function conAreaExtend (item){
    // item.style.width = "auto";
    // item.style.maxWidth = "100%";
    item.style.float = "none";
    item.style.margin = "0 auto";
    item.style.padding = "0";
}

function conAreaDel(item, state){
    // if(true == state){ insertTrace(item) }
    // if(true == state) insertTrace(item)
    if(state){
        // insertTrace(item);
    }
    item.remove();
}

function conAreaStyle(item){
    item.style.position = "absolute";
    item.style.top = "0px";
    item.style.left = "0px";
    item.style.width = "0px";
    item.style.minWidth = "0px";
    item.style.height = "0px";
    item.style.minHeight = "0px";
    item.style.margin = "0px";
    item.style.padding = "0px";
    item.style.opacity = "0";
    item.style.overflow = "hidden";
}

function insertTrace(target){
    const testDiv = document.createElement("div");
    testDiv.classList.add("traceDiv")
    let tempconInner = `<div><span>광고영역 제거됨 / 광고를 제거해서 화면을 넓게 써보자.</span></div>`;
    testDiv.innerHTML = tempconInner;
    target.parentNode.insertBefore(testDiv, target.nextSibling);
}


function naverAfterLine(){
    console.log("naverAfterLine")
    let naverNewsDiv = document.createElement("div");
    naverNewsDiv.classList.add("after");
    
    let newsTest = document.querySelector(".end_container");
    let tempStyle = `
        <style>
        .ct_scroll_wrapper::after {display:none !important;}

        @media (min-width: 1080px) {
            .as_section_home .column0 + .newsct_wrapper {
                // width: 645px;
                // padding-left: 30px;
                // padding-right: 31px;
                // flex: 1;
                // padding: 30px 30px !important;
            }
        }
        </style>
    `;
    naverNewsDiv.innerHTML = tempStyle;
    newsTest.parentNode.insertBefore(naverNewsDiv, newsTest.nextSibling);
}





function addImportant(target){
    const div = document.createElement("div");
    div.classList.add("custom_css");
    div.classList.add("inject");
    let tempconInner = `
        <style>
        .conExtend {float:unset; margin:0 auto; padding:0;}
        .traceDiv {margin:1px; padding:10px; background-color:#f9f9f9; color:#666; font-size:12px; line-height:1em; text-align:center;}
        .display-none-important {display:none !important;}
        .hideDDAction {animation: hideAnimation 0.3s 1 forwards ease;}
        @keyframes hideAnimation {
            0% {}
            100% {height:0; margin:0; padding:0; opacity:0; transform:scale(0.5); transform-origin:50% 0; z-index:0; overflow:hidden;}
        }
        </style>
    `;
    div.innerHTML = tempconInner;
    target.parentNode.insertBefore(div, target.nextSibling);
}
window.addImportant = addImportant;





function customCssInsert(customCss, name){
    const styleItem = customCss;
    const style = document.createElement("style");
    style.id = "custom-style-" + name; // 중복 방지용 ID
    style.textContent = styleItem;
    document.documentElement.appendChild(style);// HTML 루트에 삽입
}