console.log("communication.js");
window.addEventListener("load", function(){

    /* body 다음 태그에 custom css 추가 (inject.js 파일에 있음.) */
    let bodyTag = this.document.querySelector("body");
    addImportantCss(bodyTag);





    /* dcinside */

    /* 갤러리 리스트 상단 */
    let issueContentbox = this.document.querySelector(".issue_contentbox");
    if(issueContentbox) {
        issueContentbox.classList.add(displayNoneImportant);
    }

    let taboolaRightRailThumbnails = this.document.querySelector("#taboola-right-rail-thumbnails");
    if(taboolaRightRailThumbnails) {
        taboolaRightRailThumbnails.classList.add(displayNoneImportant);
    }

    let rightbanner1 = this.document.querySelector(".rightbanner1");
    if(rightbanner1) {
        rightbanner1.classList.add(displayNoneImportant);
    }

    let stickyunit = this.document.querySelector(".stickyunit");
    if(stickyunit) {
        stickyunit.classList.add(displayNoneImportant);
    }

    /* 디시트랜드 랭킹 */
    let dctrendanking = this.document.querySelector(".dctrend_ranking");
    if(dctrendanking) {
        dctrendanking.classList.add(displayNoneImportant);
    }

    function addImportantCss(target){
        const div = document.createElement("div");
        div.classList.add("custom_css")
        let tempconInner = `
            <style>
            .gall_list tr.thum .gall_tit {height:auto;}
            .gall_list td {padding:10px;}
            </style>
            `;
        div.innerHTML = tempconInner;
        target.parentNode.insertBefore(div, target.nextSibling);
    }
    window.addImportantCss = addImportantCss;
    
    /* // dcinside */




    
});
// window.addEventListener("load", function(){})