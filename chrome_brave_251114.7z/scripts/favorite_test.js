console.log("favorite.js");

// danawa
if(url.includes("danawa.com")){

    // 상단 서브 메뉴 (비교사이트)
    let cwGnb = this.document.querySelector(".cw-gnb");
    if(cwGnb) {
        conAreaDel(cwGnb, false);
    }

    // 메인 메뉴 디자인 변경용 css
    let divElement = document.createElement('div');
    divElement.classList.add("danawa");
    divElement.innerHTML = `
    <style>
    .category__list__btn {box-sizing:border-box; justify-content:space-between; width:100%; height:auto; padding-right:8px; font-size:14px; color:#fff; font-weight:600; text-indent:0; text-decoration:none; text-shadow:0 1px 2px rgba(0,0,0,0.16);}
    .category__list__row.active .category__list__btn {color:#000; text-decoration:none;}
    .aside-vs>.box__layer>.box__inner {width:270px;}
    .aside-vs>.box__layer .list__slot .box__product .box__thumbnail {width:80px;}
    // .category__list__btn:before {content:unset;}

    #brandHallArea {display:none !important;}
    </style>
    `
    document.body.appendChild(divElement); // body 안에 삽입
    // document.documentElement.appendChild(divElement); // html 안에 삽입
}

if(url.includes("prod.danawa.com")){
    /* 배너 영역 삭제 관련 */
    // 선택자와 conAreaDel의 두 번째 인자를 한 번에 정의
    const elementsToRemove = [
        { selector: "#main-middlebnr", removeFlag: true }, // 메인 중앙 배너 영역 삭제
        { selector: ".ttop_banner", removeFlag: false }, // 다나와 상단 광고,
        { selector: "#mainAdReader", removeFlag: true }, // 상품 목록 상단 광고 영역 애드 리더
        { selector: "#adPointArea", removeFlag: true }, // 상품 목록 중간 광고 영역 : 애드 포인트
        { selector: "#premiumBanner", removeFlag: false }, // 왼쪽 날개배너 프리미엄 배너
        { selector: "#naverPowerShoppingArea", removeFlag: true }, // 상품 목록 페이지 상단 광고 영역 : 이런 상품 어때요
        { selector: "#ebayPowerClickBottomArea", removeFlag: true }, // 상품 목록 페이지 하단 광고 영역 : 파워클릭
        { selector: ".aside_media", removeFlag: false, extra: () => {
            const danawaContainer = document.querySelector("#danawa_container");
            if (danawaContainer) danawaContainer.style.paddingRight = "0";
        }}, // 상품목록 우측 영역
    ];
    
    // 배열을 순회하며 각 객체를 처리
    elementsToRemove.forEach(item => {
        const el = document.querySelector(item.selector);
        if (el) {
            // 추가 작업이 있을 경우 실행
            if (item.extra) item.extra();
            conAreaDel(el, item.removeFlag);
        }
    });
    /* // 배너 영역 삭제 관련 */

    /* 상품 비교 선택시 aside-vs 영역 간섭 수정 */
    // 감시 대상 요소 선택
    const targetElement = document.querySelector('.aside-vs');
    // padding을 변경할 컨테이너 선택
    const danawaContainer = document.querySelector("#danawa_container");
    // 화면 너비 기준점
    const breakpoint = 1520;

    if (targetElement && danawaContainer) {
        // MutationObserver 콜백 함수 정의
        const observer = new MutationObserver((mutationsList) => {
            for (const mutation of mutationsList) {
                // 클래스 속성 변경일 경우만 처리
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    const hasOnClass = targetElement.classList.contains('on');

                    // 화면 너비가 breakpoint보다 작으면 padding 조정
                    if (window.innerWidth < breakpoint) {
                        danawaContainer.style.paddingRight = hasOnClass ? "280px" : "0";
                    }
                }
            }
        });

        // Observer 설정: class 속성 변경만 감지
        observer.observe(targetElement, {
            attributes: true,
            attributeFilter: ['class']
        });
    }
    /* // 상품 비교 선택시 aside-vs 영역 간섭 수정 */

} // danawa.com





// https://namu.wiki/
if(url.includes("https://namu.wiki/w/")){
    console.log("나무위키");
    /* 나무위키 구글 광고 제거 */
    // setTimeout(() => {
    //     let googleAdsIframe = document.querySelectorAll("iframe");
    //     if(googleAdsIframe.length > 0) {
    //         googleAdsIframe.forEach(function(item,index){
    //             let iframeDiv = item.closest("div");
    //             if(iframeDiv) {
    //                 item.classList.add("아이프레임");
    //                 item.style.display = "none";
    //                 iframeDiv.style.display = "none";
    //                 iframeDiv.classList.add(displayNoneImportant);
    //             }
    //         })
    //     }
    // }, 5000)
    /* // 나무위키 구글 광고 제거 */

    setTimeout(() => {
        let googleAdsIframe = document.querySelectorAll("iframe");
        if(googleAdsIframe.length > 0) {
            googleAdsIframe.forEach(function(item,index){

                let iframeDiv = item.closest("div");
                let iframeDivId;
                if(iframeDiv) {
                    iframeDivId = iframeDiv.getAttribute("id");
                }
                if(iframeDivId && typeof iframeDivId === "string" && iframeDivId.includes("google_ads_iframe")) {
                    
                    let secondDivTest = iframeDiv.parentElement;
                    let thirdDivTest = secondDivTest.parentElement;
                    console.log(secondDivTest);
                    console.log(thirdDivTest);
                    hideAnimation(thirdDivTest, true);
                    // thirdDivTest.style.display = "none";
                }
            })
        }
    }, 1000)

    setTimeout(() => {
        let divTemp = document.querySelectorAll("div");
        if(divTemp.length > 0){
            divTemp.forEach(function(item,index){
                let dddiv = item;
                let xxxdiv;
                if(dddiv) {
                    xxxdiv = dddiv.getAttribute("id");
                }
                if(xxxdiv  &&  typeof xxxdiv === "string" && xxxdiv.includes("google_ads_iframe")){
                    let firstDiv = item.parentElement;
                    let secondDivTest = firstDiv.parentElement;
                    hideAnimation(secondDivTest, true);
                    // secondDivTest.style.display = "none";
                }
            })
        }
        
    }, 1000)

} // https://namu.wiki/





// 네이버 검색 결과 화면 상단 파워링크 영역 삭제 
if(url.includes("https://search.naver.com/search.naver")){
    let ad_section = this.document.querySelector(".ad_section");
    if(ad_section){
        hideAnimation(ad_section, true)
    }
}
// 네이버 검색 결과 화면 상단 파워링크 영역 삭제 

/* 네이버 뉴스 */
if (url.includes("news.naver.com")){
    let outsideArea = document.querySelector(".outside_area");
    if(outsideArea) {
        conAreaHidden(outsideArea);
    }

    let mainAside = document.querySelector("aside.main_aside");
    if(mainAside) {
        conAreaHidden(mainAside);
    }

    let newsctWrapper = document.querySelector(".newsct_wrapper");
    if(newsctWrapper) {
        newsctWrapper.style.margin = "0 auto";
        newsctWrapper.style.padding = "30px 0";
        newsctWrapper.style.zIndex = 1;
    }

    // 언론사 구독 후 기사보기
    let subscribeCtaLayer = document.querySelectorAll(".subscribe_cta_layer")
    if(subscribeCtaLayer.length > 0){
        subscribeCtaLayer.forEach(function(item){
            conAreaDel(item);
        })
    }

    let pressAside = document.querySelector("section.press_aside");
    if(pressAside) {
        conAreaDel(pressAside);
    }
    
    let newsLine = document.querySelector(".ct_scroll_wrapper");
    if(newsLine) {
        naverAfterLine();
        // newsLine.style.opacity = "0";
    }

    let adArea = this.document.querySelector(".ad_area");
    if(adArea) {
        conAreaDel(adArea);
    }
}
// 네이버 뉴스





// https://manatoki468.net/
if(url.includes("manatoki")){
    
    let mainBannerView = this.document.querySelector("#main-banner-view");
    if(mainBannerView) {
        hideAnimation(mainBannerView, true);
        // conAreaDel(mainBannerView, true);
    }

    let hd_pop = this.document.querySelector("#hd_pop"); // 메인페이지 팝업
    if(hd_pop){
        let hd_pop_btns = hd_pop.querySelectorAll("button.hd_pops_close");
        if(hd_pop_btns && hd_pop_btns.length > 0) {
            hd_pop_btns.forEach(function(item){
                item.click();
            })
        }
    }
    
    if(url.includes("comic")){ // 뷰페이지에서만 가림
        let atWrap = this.document.querySelector("#at-wrap");
        if(atWrap) {
            atWrap.style.paddingRight = "0"
        }
        
        let atRight = this.document.querySelector("#at-right");
        if(atRight) {
            conAreaDel(atRight, true);
        }
    }
} // https://manatoki468.net/


// https://manatoki468.net/
if(url.includes("manatoki")){
    /* 배너 영역 삭제 관련 */
    // 선택자와 conAreaDel의 두 번째 인자를 한 번에 정의
    const elementsToRemove = [
        { selector: "#id_mbv", removeFlag: true }, // ㅇㅇㅇ
        { selector: ".board-tail-banner", removeFlag: true }, // ㅇㅇㅇ
/*
        { selector: "ㅇㅇㅇ", removeFlag: true }, // ㅇㅇㅇ
        { selector: "ㅇㅇㅇ", removeFlag: false, extra: () => {
            const danawaContainer = document.querySelector("#danawa_container");
            if (danawaContainer) danawaContainer.style.paddingRight = "0";
        }}, // 상품목록 우측 영역
*/
    ];
    
    // 배열을 순회하며 각 객체를 처리
    elementsToRemove.forEach(item => {
        const el = document.querySelector(item.selector);
        if (el) {
            // 추가 작업이 있을 경우 실행
            if (item.extra) item.extra();
            conAreaDel(el, item.removeFlag);
        }
    });
    /* // 배너 영역 삭제 관련 */
}
// // https://manatoki468.net/




// gemini.google.com 또는 chatgpt.com 감지
if (/(chatgpt\.com|gemini\.google\.com)/.test(url)) {
    
    // 이미 스타일이 삽입되었다면 다시 추가하지 않도록 방지
    if (!document.getElementById("gpt-style")) {

        const style = document.createElement("style");
        const maxWidth = 1440;
        style.id = "gpt-style"; // 중복 방지용 ID
        style.textContent = `
/* 컨텐츠 가로 크기 확대 */
.conversation-container,
.conversation-container > user-query,
.text-base > div:first-of-type {max-width:${maxWidth}px !important;}
.w-fit {width:auto;}
        `;

        document.documentElement.appendChild(style);// HTML 루트에 삽입
    }
}
// gemini.google.com 또는 chatgpt.com 감지





