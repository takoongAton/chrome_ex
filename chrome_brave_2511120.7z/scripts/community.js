console.log("communication.js");

/* dcinside */
if(url.includes("dcinside.com")){
    /* 갤러리 리스트 상단 */
    let issueContentbox = this.document.querySelector(".issue_contentbox");
    if(issueContentbox) {
        console.log(issueContentbox);
        issueContentbox.classList.add(displayNoneImportant);
    }

    let taboolaRightRailThumbnails = this.document.querySelector("#taboola-right-rail-thumbnails");
    if(taboolaRightRailThumbnails) {
        console.log(taboolaRightRailThumbnails);
        taboolaRightRailThumbnails.classList.add(displayNoneImportant);
    }

    let rightbanner1 = this.document.querySelector(".rightbanner1");
    if(rightbanner1) {
        console.log(rightbanner1);
        rightbanner1.classList.add(displayNoneImportant);
    }

    let stickyunit = this.document.querySelector(".stickyunit");
    if(stickyunit) {
        console.log(stickyunit);
        stickyunit.classList.add(displayNoneImportant);
    }

    /* 디시트랜드 랭킹 */
    let dctrendanking = this.document.querySelector(".dctrend_ranking");
    if(dctrendanking) {
        console.log(dctrendanking);
        dctrendanking.classList.add(displayNoneImportant);
    }

    /* custom css */
    const customCss = `
        .gall_list tr.thum .gall_tit {height:auto;}
        .gall_list td {padding:10px;}
    `;
    customCssInsert(customCss, "dcinside");
    /* // custom css */

}
/* // dcinside */
