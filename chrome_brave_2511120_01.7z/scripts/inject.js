// brave 브라우저 확인
console.log("inject.js");


/* url 공통 사용 */
const url = window.location.href;
let displayNoneImportant = "display-none-important";



// 화면에 뜨면 삭제 하는 것들.
let delArr = [
    ".fc-ab-root", // 광고 차단 허용, 스크롤 강제막기 삭제
    ".fc-whitelist-root", // 광고차단 머시기
    "#coupang-banner", // 쿠팡 상단 광고
    ".gnb_bnr_wrap", // SSG.COm 상단 광고
    ".box__component-bigs-filter", // G마켓 플로팅 배너
    "#Banner1", // 잡코리아 상단 광고
];

// 삭제하면 오류가 나서 숨겨만 놔야 하는 것들.
let hiddenArr = [
    ".AdBanner_display_ad_area__s3FEt",
    "#gladbanner.banner_wrap",
    "#view_ad02 + span"
];





/* 삭제불가, display:none 불가 인 경우 사용 */
function conAreaStyle(item){
    if(!item) {alert("없는게 걸렸따.")}
    item.style.position = "absolute";
    item.style.top = "0px";
    item.style.left = "0px";
    item.style.width = "0px";
    item.style.minWidth = "0px";
    item.style.height = "0px";
    item.style.minHeight = "0px";
    item.style.margin = "0px";
    item.style.padding = "0px";
    item.style.opacity = "0";
    item.style.overflow = "hidden";
}




/* fadeOut animation */
function hideAnimation(target, aniBoolean){
    let targetItem = target;
    let flag = aniBoolean;
    targetItem.style.height = targetItem.clientHeight + "px";
    targetItem.classList.add("hideDDAction");
    fnAnimationEnd(targetItem, flag);
}

/* fadeOut -> display:none */
function fnAnimationEnd(endItem, aniState){
    let aniFlag = aniState;
    if(aniFlag){
        endItem.addEventListener("animationend", function(){
            endItem.classList.add("display-none-important")
        })
    } else {
        endItem.classList.add("display-none-important")
    }
}

function hiddenAction(){
    document.body.style.overflow = "";
    const delList = document.querySelectorAll(delArr);
    if(delList.length > 0) {
        delList.forEach(function(item){
            if(item) {
                console.log(item);
                item.remove();
                console.log("삭제됨.")
            }
        })
    }

    const hiddenList = document.querySelectorAll(hiddenArr);
    if(hiddenList.length > 0) {
        hiddenList.forEach(function(item){
            item.style.margin = "0";
            item.style.padding = "0";
            item.style.height = "0";
            item.style.overflow = "hidden";
            item.style.opacity = "0";
            item.style.minHeight = "0";
        })
        alert("hiddenArr")
    }
}

function fnObserver(){
    const elementToObserve = document.querySelector('body');
    const observer = new MutationObserver(function(mutations) {
        console.log("est")
        mutations.forEach(function(mutation) {
            if (mutation.type == 'childList'){
                hiddenAction();
            }
        });
    });

    const config = {
        attributes:false, 
        childList:true, 
        characterData:false, 
        subtree:true
    };

    observer.observe(elementToObserve, config);
    
    setTimeout(() => {
        console.log("observer.disconnect();")
        observer.disconnect(); 
    }, 5000);
    // observer.disconnect();
}
// fnObserver();





/* 불필요한 내용 숨기기 */
function conAreaHidden(item){
    item.style.display = "none";
}





/* 기사 본문 영역 확장 */
function conAreaExtend (item){
    item.style.float = "none";
    item.style.margin = "0 auto";
}





/* 영역 삭제, 지워짐 표시 여부 확인 */
function conAreaDel(item, flagState){
    if(flagState){ // true, false
        insertTrace(item); // 지워짐 표시
    }
    console.log(item); // 삭제된 컨텐츠
    item.remove();
}





/* 광고 지워짐 표시 */
function insertTrace(target){
    const testDiv = document.createElement("div");
    testDiv.classList.add("traceDiv")
    let tempconInner = `<div><span>광고영역 제거됨 / 광고를 제거해서 화면을 넓게 써보자.</span></div>`;
    testDiv.innerHTML = tempconInner;
    target.parentNode.insertBefore(testDiv, target.nextSibling);
}





/* css 페이지에 넣기 */
function customCssInsert(customCss, name){
    const styleItem = customCss;
    const style = document.createElement("style");
    style.id = "custom-style-" + name; // 중복 방지용 ID
    style.textContent = styleItem;
    document.documentElement.appendChild(style);// HTML 루트에 삽입
}





/* 공통 적용 css */
function commonCss(){
    /* custom css */
    let siteName = 'common';
    const customCss = `
        .traceDiv {margin:1px; padding:10px; background-color:#f9f9f9; color:#666; font-size:12px; line-height:1em; text-align:center;}
        .display-none-important {display:none !important;}
        .hideDDAction {animation: hideAnimation 0.3s 1 forwards ease;}
        @keyframes hideAnimation {
            0% {}
            100% {height:0; margin:0; padding:0; opacity:0; transform:scale(0.5); transform-origin:50% 0; z-index:0; overflow:hidden;}
        }
    `;
    customCssInsert(customCss, siteName);
    /* // custom css */
}
commonCss();





function processElementRemoval(targets) {
    targets.forEach(item => {
        // selector는 단일 문자열로 처리 (여러 개 선택됨)
        const elements = document.querySelectorAll(item.selector);

        // 해당 selector에 매칭되는 요소가 하나도 없으면 종료
        if (elements.length === 0) return;

        if (item.extra) {
            item.extra(elements);  // elements 전달도 가능
            // return;  // elements 전달도 가능
        };

        // extra가 없으면 → 여러 요소 모두 처리
        elements.forEach(el => {
            conAreaDel(el, item.removeFlag);
        });
    });
}











window.addEventListener("load", function(){
    console.log("load");

    setTimeout(() => {
        let fcAbRoot = document.querySelector(".fc-ab-root");
        if(fcAbRoot) {
            fcAbRoot.style.display = "none";
            fcAbRoot.remove();
            document.body.style.overflow = "";
        }
        if(fcAbRoot) {
            console.log("setTimeout fc-ab-root 광고 제거");
        }
    }, 10)



    if (url.includes("daum.net")) {
        /* custom css */
        let siteName = 'daum';
        const customCss = `
            /* 다음 뉴스 중앙 정렬 */
            .conExtend {float:unset; margin:0 auto; padding:0;}
        `;
        customCssInsert(customCss, siteName);
        /* // custom css */
    }

    
    /* 다음 메인 */
    if (url.includes("https://www.daum.net/")){
        let daumMain = document.querySelectorAll(".inner_main .board_g.board_banner");
        if(daumMain) {
            daumMain.forEach(function(item){
                conAreaDel(item);
            })
        }

        /* 메인 쇼핑 */
        let board_shopping = this.document.querySelector(".board_g.board_shopping");
        if(board_shopping) {
            board_shopping.style.display = "none";
        }
        /* // 메인 쇼핑 */

        let daumMainAsideBnr = document.querySelectorAll(".box_g.box_adgoogle");
        if(daumMainAsideBnr) {
            daumMainAsideBnr.forEach(function(item){
                conAreaDel(item);
            })
        }

        // aside 쇼핑 삭제
        let kakao_ad_area = this.document.querySelector(".kakao_ad_area");
        if(kakao_ad_area) {
            kakao_ad_area.closest(".box_g").style.display = "none";
        }

        /* 메인 추천 게임 */
        let box_game = this.document.querySelector(".box_g.box_game")
        if(box_game) {
            box_game.style.display = "none";
        }
        /* // 메인 추천 게임 */

        /* 메인 핫딜 */
        // shoppinghow-1739518615497
        let hotdeal = this.document.querySelectorAll(".box_g > iframe");
        if(hotdeal) {
            hotdeal.forEach(function(item){
                let attrrrr = item.getAttribute("id");;
                if(attrrrr.includes("shoppinghow")){
                    item.closest(".box_g").style.display = "none";
                }
            })
        }
        /* // 메인 핫딜 */

        /* 메인 aside 랭킹 */
        let box_ranking = this.document.querySelector(".box_g.box_ranking")
        if(box_ranking) {
            box_ranking.style.display = "none";
        }
        /* // 메인 aside 랭킹 */
    }
    /* // 다음 메인 */


    /* 다음 뉴스 */
    if (url.includes("v.daum.net")){
        /* 기사 우측 추가 영역 */
        let daumAside = document.querySelector("body aside.main-etc");
        if(daumAside) {
            daumAside.classList.add("display-none-important")
            conAreaHidden(daumAside);
        }
        let mainContent = document.querySelector("div.main-content");
        if(mainContent) {
            conAreaExtend(mainContent);
            mainContent.classList.add("conExtend");
        }
        let ttalkView = document.querySelector("div.ttalk_view");
        if(ttalkView) {
            conAreaHidden(ttalkView);
        }

        let adBody2 = document.querySelector("div.ad_body2")
        if(adBody2) {
            conAreaHidden(adBody2);
        }
    }




    // 다음 검색 결과 화면
    if(url.includes("https://search.daum.net/")){
        /* 검색결과 화면의 파워링크, 스페셜링크, 프리미엄링크, 애드센스, 스폰서 박스(aside) 삭제 */
        let ad_sch = this.document.querySelectorAll(".ad_sch, .content_sponso, .content_ad, #psbColl");
        if(ad_sch.length > 0){
            ad_sch.forEach(function(item){
                let itemTest = item.parentElement;
                hideAnimation(itemTest, true);
            })
        }
    }
    // 다음 검색 결과 화면 (https://search.daum.net/...)




})